const express = require("express");
const apiRoutes = express.Router();

const userRoutes = require("./user_Rutas");                  //Rutas
const userRoutes2 = require("./role_Rutas");
const userRoutes3 = require("./task_Rutas");


apiRoutes.use("/user", userRoutes);                         //Invocación de las Rutas
apiRoutes.use("/role", userRoutes2);
apiRoutes.use("/task", userRoutes3);

module.exports = apiRoutes;