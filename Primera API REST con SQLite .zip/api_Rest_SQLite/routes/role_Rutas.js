const express = require("express");

const userModel = require("../models/Role")
const userRoutes = express.Router();

userRoutes.get("/", async (req, res) =>                         //Ruta para ver todos mis usuarios
{
    const data = await userModel.findAll();
    
    res.json( { status: 200, data: data } )
});

userRoutes.post("/create", async (req, res) =>                      //Ruta de creación 
{
    const data = await userModel.create(req.body);
    
    res.json( { status: 200, data: data } );
});


userRoutes.delete("/:id", (req, res) =>                             //Ruta para eliminar por ID
{
    userModel.destroy( 
        {
            where: 
            {
                id: req.params.id
            }
        } ).then((data) => 
        {
            res.json( { status: 200, data: data } )
        });
});

userRoutes.put("/:id", async (req, res) =>                          //Ruta para actualizar a través de ID
{
    const data = await userModel.update(req.body , 
        {
            where: 
            {
                id: req.params.id
            }
        });

    res.json( { status: 200, data } );
});

userRoutes.get("/:id", async (req, res) =>                          //Ruta de filtración a través de ID
{
    const data = await userModel.findOne( 
        {
            where: 
            {
                id: req.params.id
            }
        });

        res.json( { status: 200, data } );
});                        

module.exports = userRoutes;