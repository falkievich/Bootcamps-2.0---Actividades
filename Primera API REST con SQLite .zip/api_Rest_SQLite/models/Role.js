const { DataTypes } = require("sequelize");
const db = require("./index");

const userModel = db.define( "role", 
{
    name: DataTypes.STRING,
    description: DataTypes.STRING
} );

module.exports = userModel;