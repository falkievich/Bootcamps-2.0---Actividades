const { DataTypes } = require("sequelize");
const db = require("./index");

const userModel = db.define( "task", 
{
    name: DataTypes.STRING,
    description: DataTypes.STRING
} );

module.exports = userModel;