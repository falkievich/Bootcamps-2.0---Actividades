const Sequelize = require("sequelize");

const db = new Sequelize.Sequelize("sqlite::memory:");      //Creación de base de datos

module.exports =db;