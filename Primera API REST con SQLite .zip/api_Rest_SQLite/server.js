const express = require("express");
const app = express();

app.use(express.json());

const apiRoutes = require("./routes/index");                        //Rutas
const db = require("./models");                           //Busco mi base de datos

app.use("/api", apiRoutes);                                        //Invocación de Rutas





db.sync().then( () =>                                     //Conectar con el servidor SQLite
{
    console.log("\nSe ha conectado a SQLite");
} ).catch( () => 
{
    console.log("\nHubo un error al momento de conectar con SQLite");
});

app.listen(3000, "localhost", () => 
{
    console.log("\nEl servidor funciona en el puerto 3000\n");
});