const autenticado = (req, res, next) => 
{
    console.log("\nEfectivamente, el usuario esta autenticado.");
    next();
}

module.exports = autenticado;