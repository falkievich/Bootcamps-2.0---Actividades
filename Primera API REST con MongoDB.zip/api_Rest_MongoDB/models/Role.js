const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userSchema = new Schema 
({
    id : String,
    name : String,
    description : String
});

const userModel = mongoose.model("Role", userSchema);

module.exports = userModel;