const express = require("express");
const userModel = require("../models/Task.js");

const route = express.Router();

route.post("/create", (req, res) =>                 //Ruta de creación 
{
    console.log("\nEl body es: ", req.body);

    const user = new userModel(req.body);      //Nuevo documento para la base de d.

    user.save().then( (document) => 
    {
        res.json( {status : 200, data: document } );
    }).catch( (error) => 
    {
        res.json( {status : 500 , data : error} );
    } );
});

route.get("/:id", (req, res) =>                     //Ruta de filtración a través de ID
{
    userModel.find( { id: req.params.id } , (error, data) => 
    {
        if(error)
        {
            res.json( { status: 500, data } );
        }

        res.json( { status: 200, data } );
    });
});

route.get("/", (req, res) =>                        //Ruta para traer todos los usuarios
{
    userModel.find( {  } , (error, data) => 
    {
        if(error)
        {
            res.json( { status: 500, data } );
        }

        res.json( { status: 200, data } );
    });
});

route.delete("/:id", (req, res) =>                  //Ruta para eliminar usuario a través de ID
{
    userModel.findOneAndDelete( { id: req.params.id }, {}, (error, data) =>
    {
        if(error)
        {
            res.json( { status: 500, data } );
        }

        res.json( { status: 200, data } );
    });
});

route.put("/:id", (req, res) =>                     //Ruta para actualizar a través de ID
{
    userModel.findOneAndUpdate( { id: req.params.id }, req.body, { new:true }, (error, data) => 
    {
        if(error)
        {
            res.json( { status: 500, data } );
        }

        res.json( { status: 200, data } );
    });
});

module.exports = route;