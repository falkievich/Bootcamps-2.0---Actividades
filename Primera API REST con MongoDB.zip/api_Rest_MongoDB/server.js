const express = require("express");   
const mongoose = require("mongoose");

const app = express();
app.use(express.json() );               // NO OLVIDARSE DE ESCRIBIR ESTO DE VUELTA 

const autenticado = require("./middlewares/user_autenticado.js");           //Rutas
const userRoute = require ("./routes/user_Rutas");
const userRoute2 = require ("./routes/role_Rutas");   
const userRoute3 = require("./routes/task_Rutas");                            

app.use("/user", autenticado, userRoute); // Invocación de rutas
app.use("/role", userRoute2);
app.use("/task", userRoute3);


mongoose.connect("mongodb://127.0.0.1:27017/api_Rest_MongoDB", (error) =>  //En vez de poner mongodb://localhost:27017 poner 127.0.0.1 en lugar de localhost
{
    if(error)
    {
        console.log("\nHubo un error en la conexión a Mongo", error);
    }
    else
    {
        console.log("\nConexion exitosa con MongoDB");
    }
});

app.listen(3000);